# fhir.education.kursig#0.1.0: FHIR-utbildning – Region Stockholm - Daniel

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [FHIR-utbildning – Region Stockholm - Daniel](index.md)

### Examples

* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
