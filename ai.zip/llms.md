# fhir.education.kursig#0.1.0: FHIR-utbildning – Region Stockholm - Daniel

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Min första profile (encounter)](StructureDefinition-EducationEncounter.md)
* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [FHIR-utbildning – Region Stockholm - Daniel](index.md)

### Examples

* [encounter-tolvan-1 (Encounter)](Encounter-encounter-tolvan-1.md)
* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
